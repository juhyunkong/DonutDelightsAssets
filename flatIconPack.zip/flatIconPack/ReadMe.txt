I would love to see what project you have used these icons on.

Email: me@allanmcavoy.co.uk

Why not follow me on twitter or dribbble?

Thanks